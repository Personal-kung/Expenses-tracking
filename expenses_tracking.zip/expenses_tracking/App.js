import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

import HomeScreen from './HomeScreen';
import RegisterScreen from './RegisterScreen';
import ExpenseTableScreen from './DashboardScreen'; //table view only 
import DetailScreen from './DetailsScreen';
import CalculationsScreen from './calculations';
import GraphingScreen from './graphing';

import { useColorScheme } from 'react-native';
import { ExpensesProvider } from './ExpenseContext'; 

const Stack = createNativeStackNavigator();

export default function App() {
  const theme = useColorScheme(); // 'dark' or 'light'

  return (
    <ExpensesProvider>
      <NavigationContainer>
        <Stack.Navigator
          initialRouteName="Home"
          screenOptions={{
            headerStyle: {
              backgroundColor: theme === 'dark' ? '#121212' : '#fff',
            },
            headerTintColor: theme === 'dark' ? '#fff' : '#000', // text color
            headerTitleStyle: {
              fontWeight: 'bold',
            },
          }}>
          <Stack.Screen name="Home" component={HomeScreen} />
          <Stack.Screen
            name="Register"
            component={RegisterScreen}
            options={{ title: 'Register / Edit Expense' }}
          />
          <Stack.Screen name="Table" component={ExpenseTableScreen} options={{ title: 'Table View' }}/>
          <Stack.Screen name="Calculations" component={CalculationsScreen} options={{ title: 'Basic grouping' }}/>
          <Stack.Screen name="DetailScreen" component={DetailScreen} options={{ title: 'Detail Screen' }}/>
          <Stack.Screen name="Graphs" component={GraphingScreen} options={{ title: 'Basic grouping' }}/>
        </Stack.Navigator>
      </NavigationContainer>
    </ExpensesProvider>
  );
}
