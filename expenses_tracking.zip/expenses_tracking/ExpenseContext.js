import React, { createContext, useContext, useState, useEffect, ReactNode } from "react";
import AsyncStorage from "@react-native-async-storage/async-storage";

//datatypes restrictions
export type PaymentMethod = '現金' | 'JPBank' | 'JABank' | 'Revolut';

export interface ExpenseEntry {
  datetime: Date;
  amount: number;
  reason: string;
  paymentMethod: PaymentMethod;
  // optional fields
  details?: string;
  store?: string;
  sharedFor?: 'for' | 'shared';
  additionalDetails?: string;
}

//for localstorage
interface ExpenseContextType {
  expenses: ExpenseEntry[];
  addExpense: (entry: ExpenseEntry) => void;
  updateExpense: (datetimeMs: number, newData: ExpenseUpdate) => void;
  deleteExpense: (datetimeMs: number) => void;
}
const STORAGE_KEY = '@expenses_list';

// 1. Create the context
const ExpensesContext = createContext();

// 2. Create a provider component
export const ExpensesProvider = ({ children }) => {
  const [expenses, setExpenses] = useState([]);

  // Load from storage once
  useEffect(() => {
    const load = async () => {
      try {
        const json = await AsyncStorage.getItem(STORAGE_KEY);
        if (json) {
          const parsed = JSON.parse(json);
          const loaded = parsed.map(obj => ({
            ...obj,
            datetime: new Date(obj.datetime),
          }));
          setExpenses(loaded);
        }
      } catch (err) {
        console.error('Failed to load expenses from storage', err);
      }
    };
    load();
  }, []);

  // Save to storage whenever expenses change
  useEffect(() => {
    const persist = async () => {
      try {
        const serializable = expenses.map(e => ({
          ...e,
          datetime: e.datetime.toISOString(),
        }));
        await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(serializable));
      } catch (e) {
        console.error('Persist expenses error:', e);
      }
    };
    if (expenses) persist();
  }, [expenses]);

  const addExpense = (expense) => setExpenses(prev => [expense, ...prev]);
  const updateExpense = (datetimeMs, newData) =>
    setExpenses(prev =>
      prev.map(e => (e.datetime.getTime() === datetimeMs ? { ...e, ...newData } : e))
    );
  const deleteExpense = (datetimeMs) =>
    setExpenses(prev => prev.filter(e => e.datetime.getTime() !== datetimeMs));

  return (
    <ExpensesContext.Provider
      value={{ expenses, addExpense, updateExpense, deleteExpense }}
    >
      {children}
    </ExpensesContext.Provider>
  );
};

// 3. Custom hook to use the context more easily
export const useExpenses = () => {
  const context = useContext(ExpensesContext);
  if (!context) {
    throw new Error('useExpenses must be used within ExpensesProvider');
  }
  return context;
};
