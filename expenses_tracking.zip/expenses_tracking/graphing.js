import React, { useState, useMemo } from "react";
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  Dimensions,
} from "react-native";
import { useExpenses } from "./ExpenseContext";
import { LineChart } from "react-native-chart-kit";

const screenWidth = Dimensions.get("window").width;

export default function GraphingScreen() {
  const { expenses } = useExpenses();
  const [tab, setTab] = useState("All");

  const filteredData = useMemo(() => {
    if (tab === "All") return expenses;
    if (tab === "Income") return expenses.filter((e) => e.amount > 0);
    return expenses.filter((e) => e.amount < 0);
  }, [tab, expenses]);

  // Aggregate data by key (paymentMethod or reason)
  const aggregateBy = (key) => {
    const map = {};
    filteredData.forEach((e) => {
      const k = e[key];
      if (!map[k]) map[k] = 0;
      map[k] += e.amount;
    });
    const labels = Object.keys(map);
    const data = Object.values(map).map((v) => parseFloat(v.toFixed(2)));
    return { labels, data };
  };

  const paymentData = aggregateBy("paymentMethod");
  const reasonData = aggregateBy("reason");

  return (
    <ScrollView style={styles.container}>
      {/* Tab layout */}
      <View style={styles.tabRow}>
        {["All", "Income", "Expenses"].map((t) => (
          <TouchableOpacity
            key={t}
            style={[styles.tabItem, tab === t && styles.tabActive]}
            onPress={() => setTab(t)}
          >
            <Text style={styles.tabText}>{t}</Text>
          </TouchableOpacity>
        ))}
      </View>

      {/* Line Chart - Payment Method */}
      <Text style={styles.chartLabel}>By Payment Method</Text>
      {paymentData.labels.length > 0 && (
        <LineChart
          data={{
            labels: paymentData.labels,
            datasets: [{ data: paymentData.data }],
          }}
          width={screenWidth - 16}
          height={220}
          yAxisLabel="$"
          chartConfig={chartConfig}
          style={styles.chart}
        />
      )}

      {/* Line Chart - Reason */}
      <Text style={styles.chartLabel}>By Reason</Text>
      {reasonData.labels.length > 0 && (
        <LineChart
          data={{
            labels: reasonData.labels,
            datasets: [{ data: reasonData.data }],
          }}
          width={screenWidth - 16}
          height={220}
          yAxisLabel="$"
          chartConfig={chartConfig}
          style={styles.chart}
        />
      )}
    </ScrollView>
  );
}

const chartConfig = {
  backgroundColor: "#121212",
  backgroundGradientFrom: "#121212",
  backgroundGradientTo: "#333",
  decimalPlaces: 2,
  color: (opacity = 1) => `rgba(187, 134, 252, ${opacity})`,
  labelColor: (opacity = 1) => `rgba(255, 255, 255, ${opacity})`,
  propsForDots: { r: "4", strokeWidth: "2", stroke: "#bb86fc" },
};

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#121212", padding: 8 },
  tabRow: { flexDirection: "row", marginVertical: 8 },
  tabItem: {
    flex: 1,
    paddingVertical: 10,
    backgroundColor: "#333",
    alignItems: "center",
    borderRadius: 6,
    marginHorizontal: 2,
  },
  tabActive: { backgroundColor: "#bb86fc" },
  tabText: { color: "#fff", fontWeight: "bold" },
  chartLabel: { color: "#fff", fontWeight: "bold", fontSize: 16, marginTop: 16, marginBottom: 4 },
  chart: { marginVertical: 8, borderRadius: 16 },
});
