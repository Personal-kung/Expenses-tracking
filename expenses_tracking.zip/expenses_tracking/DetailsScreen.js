import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
} from 'react-native';
import { useRoute, useNavigation } from '@react-navigation/native';
import { useExpenses } from './ExpenseContext';

export default function DetailScreen() {
  const route = useRoute();
  const navigation = useNavigation();
  const { expenses, deleteExpense } = useExpenses();

  const datetimeMs = route.params?.datetimeMs;

  const [entry, setEntry] = useState();
  const [prevEntry, setPrevEntry] = useState();
  const [nextEntry, setNextEntry] = useState();

  useEffect(() => {
    if (datetimeMs != null) {
      const sorted = [...expenses].sort(
        (a, b) => a.datetime.getTime() - b.datetime.getTime()
      );
      const index = sorted.findIndex(
        (e) => e.datetime.getTime() === datetimeMs
      );
      if (index >= 0) {
        setEntry(sorted[index]);
        setPrevEntry(index > 0 ? sorted[index - 1] : null);
        setNextEntry(index < sorted.length - 1 ? sorted[index + 1] : null);
      } else {
        setEntry(null);
        setPrevEntry(null);
        setNextEntry(null);
      }
    }
  }, [datetimeMs, expenses]);

  if (!entry) {
    return (
      <View style={[styles.container, styles.center]}>
        <Text style={styles.emptyText}>No detail entry found.</Text>
      </View>
    );
  }

  const handleEdit = () => {
    navigation.navigate('Register', {
      datetimeMs: entry.datetime.getTime(),
    });
  };

  const goToPrevious = () => {
    if (prevEntry) {
      navigation.replace('DetailScreen', {
        datetimeMs: prevEntry.datetime.getTime(),
      });
    }
  };

  const goToNext = () => {
    if (nextEntry) {
      navigation.replace('DetailScreen', {
        datetimeMs: nextEntry.datetime.getTime(),
      });
    }
  };

  const handleDelete = () => {
    if (entry) {
      deleteExpense(entry.datetime.getTime());
      navigation.goBack();
    }
  };

  return (
    <View style={styles.container}>
      {/* Delete button */}
      <TouchableOpacity style={styles.deleteButton} onPress={handleDelete}>
        <Text style={styles.deleteButtonText}>Delete</Text>
      </TouchableOpacity>

      <ScrollView contentContainerStyle={styles.content}>
        <Text style={styles.label}>日時:</Text>
        <Text style={styles.value}>{entry.datetime.toLocaleString()}</Text>

        <Text style={styles.label}>支払い金額:</Text>
        <Text
          style={[
            styles.value,
            entry.amount < 0 ? styles.negative : styles.positive,
          ]}
        >
          {entry.amount.toFixed(2)}
        </Text>

        <Text style={styles.label}>理由:</Text>
        <Text style={styles.value}>{entry.reason}</Text>

        <Text style={styles.label}>支払方法:</Text>
        <Text style={styles.value}>{entry.paymentMethod}</Text>

        {entry.store && (
          <>
            <Text style={styles.label}>店:</Text>
            <Text style={styles.value}>{entry.store}</Text>
          </>
        )}

        {entry.additionalDetails && (
          <>
            <Text style={styles.label}>Expense sharing:</Text>
            <Text style={styles.value}>
              {entry.sharedFor}: {entry.additionalDetails}
            </Text>
          </>
        )}
      </ScrollView>

      {/* Buttons at bottom */}
      <View style={styles.buttonRow}>
        <TouchableOpacity
          style={[styles.button, !prevEntry && styles.buttonDisabled]}
          onPress={goToPrevious}
          disabled={!prevEntry}
        >
          <Text style={[styles.buttonText, !prevEntry && styles.buttonTextDisabled]}>
            Previous
          </Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.button} onPress={handleEdit}>
          <Text style={styles.buttonText}>Edit</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={[styles.button, !nextEntry && styles.buttonDisabled]}
          onPress={goToNext}
          disabled={!nextEntry}
        >
          <Text style={[styles.buttonText, !nextEntry && styles.buttonTextDisabled]}>
            Next
          </Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#121212',
  },
  center: {
    justifyContent: 'center',
    alignItems: 'center',
  },
  content: {
    padding: 16,
    paddingBottom: 80, // leave space for buttons
  },
  label: {
    fontWeight: 'bold',
    marginTop: 12,
    fontSize: 16,
    color: '#bb86fc',
  },
  value: {
    fontSize: 16,
    marginTop: 4,
    color: '#fff',
  },
  negative: {
    color: '#cf6679',
    fontWeight: 'bold',
  },
  positive: {
    color: '#03dac6',
    fontWeight: 'bold',
  },
  buttonRow: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    paddingVertical: 12,
    borderTopWidth: 1,
    borderColor: '#333',
    backgroundColor: '#1f1f1f',
  },
  button: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderWidth: 1,
    borderColor: '#888',
    borderRadius: 4,
  },
  buttonDisabled: {
    borderColor: '#555',
    backgroundColor: '#333',
  },
  buttonText: {
    fontSize: 16,
    color: '#03dac6',
  },
  buttonTextDisabled: {
    color: '#555',
  },
  deleteButton: {
    width: '100%',
    backgroundColor: '#cf6679',
    paddingVertical: 12,
    alignItems: 'center',
  },
  deleteButtonText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
  },
  emptyText: {
    color: '#888',
    fontSize: 16,
  },
});
