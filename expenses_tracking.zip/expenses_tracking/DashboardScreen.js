import React from 'react';
import {
  View,
  Text,
  FlatList,
  TouchableOpacity,
  StyleSheet,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useExpenses } from './ExpenseContext';

export default function ExpenseTableScreen({ navigation }) {
  const { expenses } = useExpenses();

  const formatAmount = (amt) => {
    return amt.toFixed(2);
  };

  const renderItem = ({ item }) => {
    const isNeg = item.amount < 0;
    return (
      <View style={styles.row}>
        <TouchableOpacity
          onPress={() => {
            navigation.navigate('Register', {
              datetimeMs: item.datetime.getTime(),
            });
          }}
          style={styles.iconCell}
        >
          <Ionicons name="pencil" size={20} color="#bb86fc" />
        </TouchableOpacity>

        <View style={styles.cell}>
          <Text style={styles.cellText}>
            {new Date(item.datetime).toLocaleDateString()}
          </Text>
        </View>

        <View style={styles.cell}>
          <Text
            style={[
              styles.cellText,
              isNeg ? styles.negativeText : styles.positiveText,
            ]}
          >
            {formatAmount(item.amount)}
          </Text>
        </View>

        <View style={styles.cell}>
          <Text style={styles.cellText}>{item.reason}</Text>
        </View>

        <View style={styles.cell}>
          <Text style={styles.cellText}>{item.paymentMethod}</Text>
        </View>

        <TouchableOpacity
          style={styles.iconCell}
          onPress={() =>
            navigation.navigate('DetailScreen', {
              datetimeMs: item.datetime.getTime(),
            })
          }
        >
          <Ionicons name="information-circle-outline" size={20} color="#03dac6" />
        </TouchableOpacity>
      </View>
    );
  };

  return (
    <View style={styles.container}>
      {/* Table Header */}
      <View style={[styles.row, styles.headerRow]}>
        <View style={styles.headerCell}>
          <Text style={styles.headerText}>日時</Text>
        </View>
        <View style={styles.headerCell}>
          <Text style={styles.headerText}>支払い金額</Text>
        </View>
        <View style={styles.headerCell}>
          <Text style={styles.headerText}>理由</Text>
        </View>
        <View style={styles.headerCell}>
          <Text style={styles.headerText}>支払い方法</Text>
        </View>
        <View style={styles.headerCell}>
          <Text style={styles.headerText}>修正</Text>
        </View>
      </View>

      <FlatList
        data={expenses}
        keyExtractor={(item) => item.id}
        renderItem={renderItem}
        ListEmptyComponent={() => (
          <Text style={styles.emptyText}>No entries yet</Text>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 8, backgroundColor: '#121212' },
  headerRow: { backgroundColor: '#333', borderBottomWidth: 1, borderColor: '#555' },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    borderBottomWidth: 1,
    borderColor: '#333',
    paddingVertical: 8,
  },
  headerCell: { flex: 1, paddingHorizontal: 4, justifyContent: 'center' },
  headerText: { fontWeight: 'bold', textAlign: 'center', color: '#bb86fc' },
  cell: { flex: 1, paddingHorizontal: 4 },
  cellText: { color: '#fff', textAlign: 'center' },
  negativeText: { color: '#cf6679', fontWeight: 'bold' },
  positiveText: { color: '#03dac6', fontWeight: 'bold' },
  emptyText: { marginTop: 20, textAlign: 'center', color: '#888' },
  iconCell: { width: 40, justifyContent: 'center', alignItems: 'center' },
});
