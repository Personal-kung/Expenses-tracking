import React, { useState, useMemo } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  FlatList,
} from 'react-native';
import { useExpenses } from './ExpenseContext';

const PAYMENT_METHODS = ['現金', 'JPBank', 'JABank', 'Revolut']; // adjust to your methods

export default function CalculationsScreen() {
  const { expenses } = useExpenses();
  const [tab, setTab] = useState('income'); // 'income' or 'expenses'
  const [filter, setFilter] = useState('All'); // payment method or 'All'

  // Filtered and sorted data
  const filteredData = useMemo(() => {
    let data = expenses;
    if (tab === 'income') data = data.filter(e => e.amount > 0);
    if (tab === 'expenses') data = data.filter(e => e.amount < 0);
    if (filter !== 'All') data = data.filter(e => e.paymentMethod === filter);

    const freqMap = {};
    data.forEach(e => {
      if (!freqMap[e.reason]) freqMap[e.reason] = { amount: 0, frequency: 0 };
      freqMap[e.reason].amount += e.amount;
      freqMap[e.reason].frequency += 1;
    });

    return Object.entries(freqMap)
      .map(([reason, val]) => ({ reason, ...val }))
      .sort((a, b) => Math.abs(b.amount) - Math.abs(a.amount));
  }, [expenses, tab, filter]);

  // Compute total and average for summary table
  const summary = useMemo(() => {
    if (!filteredData.length) return { total: 0, average: 0 };
    const total = filteredData.reduce((sum, item) => sum + item.amount, 0);
    const average = total / filteredData.length;
    return { total, average };
  }, [filteredData]);

  return (
    <View style={styles.container}>
      {/* Tab layout */}
      <View style={styles.tabRow}>
        <TouchableOpacity
          style={[styles.tabItem, tab === 'income' && styles.tabActive]}
          onPress={() => setTab('income')}
        >
          <Text style={styles.tabText}>Income</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.tabItem, tab === 'expenses' && styles.tabActive]}
          onPress={() => setTab('expenses')}
        >
          <Text style={styles.tabText}>Expenses</Text>
        </TouchableOpacity>
      </View>

      {/* Payment method filter buttons */}
      <View style={styles.buttonRow}>
        {['All', ...PAYMENT_METHODS].map(p => (
          <TouchableOpacity
            key={p}
            style={[styles.filterButton, filter === p && styles.filterActive]}
            onPress={() => setFilter(p)}
          >
            <Text style={styles.filterText}>{p}</Text>
          </TouchableOpacity>
        ))}
      </View>

      {/* Summary table */}
      <View style={styles.summaryTable}>
        <View style={styles.summaryRow}>
          <Text style={[styles.summaryCell, styles.summaryHeader]}>Total</Text>
          <Text style={[styles.summaryCell, styles.summaryHeader]}>Average</Text>
        </View>
        <View style={styles.summaryRow}>
          <Text style={styles.summaryCell}>{summary.total.toFixed(2)}</Text>
          <Text style={styles.summaryCell}>{summary.average.toFixed(2)}</Text>
        </View>
      </View>

      {/* Main table */}
      <View style={styles.tableHeader}>
        <Text style={[styles.cell, styles.headerCell]}>Reason</Text>
        <Text style={[styles.cell, styles.headerCell]}>Amount</Text>
        <Text style={[styles.cell, styles.headerCell]}>Frequency</Text>
      </View>

      <FlatList
        data={filteredData}
        keyExtractor={item => item.reason}
        renderItem={({ item }) => (
          <View style={styles.tableRow}>
            <Text style={styles.cell}>{item.reason}</Text>
            <Text style={styles.cell}>{item.amount.toFixed(2)}</Text>
            <Text style={styles.cell}>{item.frequency}</Text>
          </View>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 8, backgroundColor: '#121212' },
  tabRow: { flexDirection: 'row', marginVertical: 8 },
  tabItem: {
    flex: 1,
    paddingVertical: 10,
    backgroundColor: '#333',
    alignItems: 'center',
    borderRadius: 6,
    marginHorizontal: 2,
  },
  tabActive: { backgroundColor: '#bb86fc' },
  tabText: { color: '#fff', fontWeight: 'bold' },
  buttonRow: { flexDirection: 'row', justifyContent: 'space-around', marginVertical: 8 },
  filterButton: { paddingVertical: 8, paddingHorizontal: 12, backgroundColor: '#333', borderRadius: 6 },
  filterActive: { backgroundColor: '#03dac6' },
  filterText: { color: '#fff' },
  summaryTable: { marginVertical: 12, borderWidth: 1, borderColor: '#888', borderRadius: 6 },
  summaryRow: { flexDirection: 'row' },
  summaryCell: { flex: 1, textAlign: 'center', padding: 8, color: '#fff' },
  summaryHeader: { fontWeight: 'bold', backgroundColor: '#333' },
  tableHeader: { flexDirection: 'row', borderBottomWidth: 1, borderColor: '#888', marginBottom: 4 },
  tableRow: { flexDirection: 'row', paddingVertical: 6, borderBottomWidth: 1, borderColor: '#333' },
  cell: { flex: 1, color: '#fff', textAlign: 'center' },
  headerCell: { fontWeight: 'bold', color: '#bb86fc' },
});